package com.amezon.AmezonDemo.service;

import com.amezon.AmezonDemo.model.Product;
import com.amezon.AmezonDemo.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    private ProductRepository repo;

    public List<Product> getAllProducts() {
        return repo.findAll();
    }

    public Product createProduct(Product product) {
        return repo.save(product);
    }
    public String getAllProductById(int id)
    {
        Optional<Product> products = repo.findById(id);
        if(products.isPresent())
        {
            Product obj = products.get();
            return obj.toString();
        }
        else {
            return "Product Not Found";
        }
    }
}
